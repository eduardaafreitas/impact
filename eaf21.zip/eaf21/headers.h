#ifndef __HEADERS__
#define __HEADERS__

#include <allegro5/allegro5.h>	
#include <allegro5/allegro_font.h>	
#include <allegro5/allegro_ttf.h>	 	
#include <allegro5/allegro_image.h>		
#include <allegro5/keyboard.h>																					
#include <allegro5/allegro_primitives.h>	
#include <allegro5/allegro_color.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <math.h>

#endif 
